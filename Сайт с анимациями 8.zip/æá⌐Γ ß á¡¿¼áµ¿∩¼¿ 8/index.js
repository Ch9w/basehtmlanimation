// $(window).scroll(function() {
//     $(".text-slide").each(function() {
//         var elementPos = $(this).offset().top;
//         var topOfWindow = $(window).scrollTop();
//         if (elementPos < topOfWindow + $(window).height()) {
//             $(this).animate({
//                 left: "0"
//             }, 1000)
//         }
//     })
// })

$(window).on('load', function () {
    $('.text-slide').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.text-logo2').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.content-1-1').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.content-2-1').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } })
    $('.content-2-2').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } })
    $('.content-3-1').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } })
    $('.content-3-2').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } })
    $('.content-4').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.content-5-1').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.content-5-2').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.content-7-1').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.content-7-2').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.table1').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.range1-1').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.range1-2').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.range2-1').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.range2-2').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.range3-1').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.range3-2').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.range4-1').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.range4-2').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.range5-1').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.range5-2').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.content-9-div1').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.content-9-div2').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.content-9-div3').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.footer').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })

})
$(window).on('scroll', function () {
    $('.text-slide').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.text-logo2').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.content-1-1').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.content-2-1').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } })
    $('.content-2-2').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } })
    $('.content-3-1').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } })
    $('.content-3-2').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } })
    $('.content-4').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.content-5-1').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.content-5-2').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.content-7-1').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.content-7-2').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.table1').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.range1-1').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.range1-2').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.range2-1').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.range2-2').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.range3-1').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.range3-2').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.range4-1').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.range4-2').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.range5-1').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.range5-2').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.content-9-div1').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.content-9-div2').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.content-9-div3').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
    $('.footer').each(function () { if ($(this).isInViewport()) { $(this).addClass('active') } else { $(this).removeClass('active') } })
})
$.fn.isInViewport = function () {
    var elementTop = $(this).offset().top;
    var elementBottom = elementTop + $(this).outerHeight()
    var viewportTop = $(window).scrollTop()
    var viewportBottom = viewportTop + $(window).height();

    return elementBottom > viewportTop && elementTop < viewportBottom;
}

$(document).ready(function () {
    var text1 = "ваш портал"
    var text2 = "ваш сервис"
    var text3 = "ваш бренд"
    var text = text1
    var i = 0
    var isDeleting = false
    setInterval(function () {
        if (!isDeleting && i < text.length) {
            $('#output').append(text.charAt(i))
            i++
        }
        else if (isDeleting && i >= 0) {
            $('#output').text($("#output").text().substring(0, i - 1))
            i--
        }
        else {
            isDeleting = !isDeleting
            if (!isDeleting) {
                if (text == text1) {
                    text = text2
                }
                else if (text == text2) {
                    text = text3
                }
                else {
                    text = text1
                }
                i = 0
            }
        }
    }
        , 100)
}

)

// document.querySelector('.input-range').addEventListener('change', function() {
//     document.querySelector('.content-8-box-img1').style.width = this.value+'%'
// })

$(function () {
    $("#slider").slider({
        min: 0,
        max: 1000,
        step: 1,
        value: 500,
        slide: function (event, ui) {
            document.querySelector('.content-8-box-img1').style.width = ui.value / 10 + '%'
        }
    });
});
